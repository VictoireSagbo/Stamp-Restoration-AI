# Global Renewable Energy Trends Analysis

A comprehensive data science project analyzing global renewable energy trends using Python. This project demonstrates various data analysis techniques including time series analysis, correlation studies, and predictive modeling.

## Features

- Synthetic data generation for renewable energy sources
- Exploratory Data Analysis (EDA)
- Time series visualization
- Correlation analysis
- Predictive modeling using Linear Regression
- Seasonal pattern analysis

## Technologies Used

- Python 3.8
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn

## Visualizations

The project generates several visualizations:
- Time series trends of renewable energy sources
- Correlation matrix between different energy types
- Monthly seasonality patterns
- Prediction model results

## Getting Started

1. Clone this repository
2. Install required packages:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn
```
3. Run the analysis:
```bash
python renewable_energy_analysis.py
```

## Project Structure

- `renewable_energy_analysis.py`: Main Python script
- `renewable_energy_analysis.ipynb`: Jupyter notebook version
- Generated visualizations:
  - `trends.png`
  - `correlations.png`
  - `seasonality.png`
  - `predictions.png`