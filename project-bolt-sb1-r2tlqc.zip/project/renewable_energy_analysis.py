import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error

# Set random seed for reproducibility
np.random.seed(42)

def generate_data():
    """Generate synthetic renewable energy data"""
    dates = pd.date_range(start='2010-01-01', end='2023-12-31', freq='M')
    n_samples = len(dates)
    
    data = {
        'Date': dates,
        'Solar': np.cumsum(np.random.normal(1, 0.2, n_samples)),
        'Wind': np.cumsum(np.random.normal(1.2, 0.3, n_samples)),
        'Hydro': np.cumsum(np.random.normal(0.5, 0.1, n_samples)),
        'Biomass': np.cumsum(np.random.normal(0.3, 0.1, n_samples))
    }
    
    return pd.DataFrame(data).set_index('Date')

def perform_eda(df):
    """Perform exploratory data analysis"""
    print("\nData Preview:")
    print(df.head())
    
    print("\nDescriptive Statistics:")
    print(df.describe())
    
    annual_growth = df.resample('Y').mean().pct_change() * 100
    print("\nAverage Annual Growth Rates:")
    print(annual_growth.mean())

def plot_trends(df):
    """Plot energy trends"""
    plt.style.use('seaborn')
    plt.figure(figsize=(12, 6))
    
    for column in df.columns:
        plt.plot(df.index, df[column], label=column, linewidth=2)
    
    plt.title('Evolution of Renewable Energy Sources (2010-2023)', fontsize=14)
    plt.xlabel('Year', fontsize=12)
    plt.ylabel('Production (normalized units)', fontsize=12)
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.savefig('trends.png')
    plt.close()

def analyze_correlations(df):
    """Analyze correlations between energy sources"""
    plt.figure(figsize=(8, 6))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm', center=0, fmt='.2f')
    plt.title('Correlation Matrix between Energy Sources', fontsize=12)
    plt.savefig('correlations.png')
    plt.close()
    
    plt.figure(figsize=(10, 5))
    sns.boxplot(data=df.reset_index(), x=df.index.month, y='Solar')
    plt.title('Monthly Solar Energy Production Distribution', fontsize=12)
    plt.xlabel('Month', fontsize=10)
    plt.ylabel('Production', fontsize=10)
    plt.savefig('seasonality.png')
    plt.close()

def build_prediction_model(df):
    """Build and evaluate prediction model"""
    X = np.arange(len(df)).reshape(-1, 1)
    y = df['Solar'].values
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    
    plt.figure(figsize=(10, 6))
    plt.scatter(X_test, y_test, color='blue', alpha=0.5, label='Actual Data')
    plt.plot(X_test, y_pred, color='red', linewidth=2, label='Predictions')
    plt.title(f'Solar Energy Production Prediction\nR² = {r2:.3f}, RMSE = {rmse:.3f}', fontsize=12)
    plt.xlabel('Time Index', fontsize=10)
    plt.ylabel('Production', fontsize=10)
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.savefig('predictions.png')
    plt.close()
    
    return r2, rmse

def main():
    print("Global Renewable Energy Trends Analysis")
    print("======================================")
    
    # Generate and analyze data
    df = generate_data()
    perform_eda(df)
    
    # Create visualizations
    print("\nGenerating visualizations...")
    plot_trends(df)
    analyze_correlations(df)
    
    # Build prediction model
    print("\nBuilding prediction model...")
    r2, rmse = build_prediction_model(df)
    
    print(f"\nModel Performance:")
    print(f"R² Score: {r2:.3f}")
    print(f"RMSE: {rmse:.3f}")
    
    print("\nAnalysis complete! Generated visualization files:")
    print("- trends.png: Time series plot of all energy sources")
    print("- correlations.png: Correlation matrix heatmap")
    print("- seasonality.png: Monthly solar production distribution")
    print("- predictions.png: Solar energy prediction results")

if __name__ == "__main__":
    main()